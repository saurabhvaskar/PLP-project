import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
// material
//toolbar //iconbadge //sidenav
import { MatToolbarModule, MatBadgeModule, MatSidenavModule } from '@angular/material'

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//carousel
import { CarouselModule } from 'ngx-bootstrap/carousel';
//search
import { NgMatSearchBarModule } from 'ng-mat-search-bar';
//grid
import { MatGridListModule } from '@angular/material/grid-list';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,//material
    NgMatSearchBarModule,//search
    MatToolbarModule,//toolbar
    MatBadgeModule,//badge
    MatSidenavModule,//sidenav
    FormsModule,
    ReactiveFormsModule,
    MatGridListModule,//grid list
    CarouselModule.forRoot()
  ],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
